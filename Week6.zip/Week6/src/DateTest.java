public class DateTest {
    public static void main(String[] args) {
        Date today=new Date(1,3,2020);
        System.out.println(today);
        today.setDate(8,11,2020);
        System.out.println(today);


    }
}
