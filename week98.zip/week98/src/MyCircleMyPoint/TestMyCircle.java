package MyCircleMyPoint;

public class TestMyCircle {
    public static void main(String[] args) {
        // Constructors

    }
}
